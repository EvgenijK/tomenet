.sv-build/linux/028a446de2f035467aca/main.o: client/sv/main.c \
  client/sv/font.h
client/sv/font.h:
