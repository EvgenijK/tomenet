.sv-build/linux/8c1ae82935084694898c/temporary/synthetic.o: \
  temporary/sv/synthetic.c temporary/sv/synthetic.h client/sv/app.h \
  client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h
temporary/sv/synthetic.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
