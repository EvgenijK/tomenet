.sv-build/linux/8c1ae82935084694898c/scenarios/geometry-scenario.o: \
  ../tests/sv/scenarios/geometry-scenario.c \
  ../tests/sv/scenarios/geometry-scenario.h client/sv/ui/ui.h \
  client/sv/ui/font.h client/sv/ui/status.h client/sv/app.h \
  client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h client/sv/ui/message-text.h \
  ../tests/sv/scenarios/native-frame.h client/sv/input/native-input.h
../tests/sv/scenarios/geometry-scenario.h:
client/sv/ui/ui.h:
client/sv/ui/font.h:
client/sv/ui/status.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/ui/message-text.h:
../tests/sv/scenarios/native-frame.h:
client/sv/input/native-input.h:
