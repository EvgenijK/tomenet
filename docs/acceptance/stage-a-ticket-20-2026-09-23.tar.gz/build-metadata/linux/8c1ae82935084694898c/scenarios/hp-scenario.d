.sv-build/linux/8c1ae82935084694898c/scenarios/hp-scenario.o: \
  ../tests/sv/scenarios/hp-scenario.c \
  ../tests/sv/scenarios/hp-scenario.h client/sv/app.h \
  client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h client/sv/ui/status.h
../tests/sv/scenarios/hp-scenario.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/ui/status.h:
