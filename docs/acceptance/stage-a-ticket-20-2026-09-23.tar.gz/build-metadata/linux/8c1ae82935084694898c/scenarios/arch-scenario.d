.sv-build/linux/8c1ae82935084694898c/scenarios/arch-scenario.o: \
  ../tests/sv/scenarios/arch-scenario.c \
  ../tests/sv/scenarios/arch-scenario.h \
  ../tests/sv/scenarios/hp-scenario.h client/sv/app.h \
  client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h
../tests/sv/scenarios/arch-scenario.h:
../tests/sv/scenarios/hp-scenario.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
