.sv-build/linux/8c1ae82935084694898c/session/alerts.o: \
  client/sv/session/alerts.c client/sv/session/alerts.h \
  client/sv/session/session.h client/sv/result.h
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
