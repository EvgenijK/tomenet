.sv-build/linux/8c1ae82935084694898c/session/session.o: \
  client/sv/session/session.c \
  client/sv/session/../../../common/angband.h \
  client/sv/session/../../../common/../common/h-basic.h \
  client/sv/session/../../../common/../common/../h-config.h \
  client/sv/session/../../../common/../common/h-system.h \
  client/sv/session/../../../common/../common/h-type.h \
  client/sv/session/../../../common/../common/h-define.h \
  client/sv/session/../../../common/../common/h-net.h \
  client/sv/session/../../../common/../common/sockbuf.h \
  client/sv/session/../../../common/../common/net-unix.h \
  client/sv/session/../../../common/../common/pack.h \
  client/sv/session/../../../common/../common/bit.h \
  client/sv/session/../../../common/../common/z-util.h \
  client/sv/session/../../../common/../common/z-virt.h \
  client/sv/session/../../../common/../common/z-form.h \
  client/sv/session/../../../common/../common/z-rand.h \
  client/sv/session/../../../common/z-term.h \
  client/sv/session/../../../common/h-basic.h \
  client/sv/session/../../../common/../config.h \
  client/sv/session/../../../common/../common/defines.h \
  client/sv/session/../../../common/../common/defines-local.h \
  client/sv/session/../../../common/../common/defines-features.h \
  client/sv/session/../../../common/../common/defines-features-local.h \
  client/sv/session/../../../common/../common/colours.h \
  client/sv/session/../../../common/../server/quests-defines.h \
  client/sv/session/../../../common/../common/types.h \
  client/sv/session/../../../common/externs.h \
  client/sv/session/../../../common/sockbuf.h \
  client/sv/protocol/hp-update.h client/sv/session/session.h \
  client/sv/result.h
client/sv/session/../../../common/angband.h:
client/sv/session/../../../common/../common/h-basic.h:
client/sv/session/../../../common/../common/../h-config.h:
client/sv/session/../../../common/../common/h-system.h:
client/sv/session/../../../common/../common/h-type.h:
client/sv/session/../../../common/../common/h-define.h:
client/sv/session/../../../common/../common/h-net.h:
client/sv/session/../../../common/../common/sockbuf.h:
client/sv/session/../../../common/../common/net-unix.h:
client/sv/session/../../../common/../common/pack.h:
client/sv/session/../../../common/../common/bit.h:
client/sv/session/../../../common/../common/z-util.h:
client/sv/session/../../../common/../common/z-virt.h:
client/sv/session/../../../common/../common/z-form.h:
client/sv/session/../../../common/../common/z-rand.h:
client/sv/session/../../../common/z-term.h:
client/sv/session/../../../common/h-basic.h:
client/sv/session/../../../common/../config.h:
client/sv/session/../../../common/../common/defines.h:
client/sv/session/../../../common/../common/defines-local.h:
client/sv/session/../../../common/../common/defines-features.h:
client/sv/session/../../../common/../common/defines-features-local.h:
client/sv/session/../../../common/../common/colours.h:
client/sv/session/../../../common/../server/quests-defines.h:
client/sv/session/../../../common/../common/types.h:
client/sv/session/../../../common/externs.h:
client/sv/session/../../../common/sockbuf.h:
client/sv/protocol/hp-update.h:
client/sv/session/session.h:
client/sv/result.h:
