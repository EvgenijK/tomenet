.sv-build/linux/8c1ae82935084694898c/ui/font.o: client/sv/ui/font.c \
  client/sv/ui/font.h /usr/include/freetype2/ft2build.h \
  /usr/include/freetype2/freetype/config/ftheader.h \
  /usr/include/freetype2/freetype/freetype.h \
  /usr/include/freetype2/freetype/config/ftconfig.h \
  /usr/include/freetype2/freetype/config/ftoption.h \
  /usr/include/freetype2/freetype/config/ftstdlib.h \
  /usr/include/freetype2/freetype/config/integer-types.h \
  /usr/include/freetype2/freetype/config/public-macros.h \
  /usr/include/freetype2/freetype/config/mac-support.h \
  /usr/include/freetype2/freetype/fttypes.h \
  /usr/include/freetype2/freetype/ftsystem.h \
  /usr/include/freetype2/freetype/ftimage.h \
  /usr/include/freetype2/freetype/fterrors.h \
  /usr/include/freetype2/freetype/ftmoderr.h \
  /usr/include/freetype2/freetype/fterrdef.h
client/sv/ui/font.h:
/usr/include/freetype2/ft2build.h:
/usr/include/freetype2/freetype/config/ftheader.h:
/usr/include/freetype2/freetype/freetype.h:
/usr/include/freetype2/freetype/config/ftconfig.h:
/usr/include/freetype2/freetype/config/ftoption.h:
/usr/include/freetype2/freetype/config/ftstdlib.h:
/usr/include/freetype2/freetype/config/integer-types.h:
/usr/include/freetype2/freetype/config/public-macros.h:
/usr/include/freetype2/freetype/config/mac-support.h:
/usr/include/freetype2/freetype/fttypes.h:
/usr/include/freetype2/freetype/ftsystem.h:
/usr/include/freetype2/freetype/ftimage.h:
/usr/include/freetype2/freetype/fterrors.h:
/usr/include/freetype2/freetype/ftmoderr.h:
/usr/include/freetype2/freetype/fterrdef.h:
