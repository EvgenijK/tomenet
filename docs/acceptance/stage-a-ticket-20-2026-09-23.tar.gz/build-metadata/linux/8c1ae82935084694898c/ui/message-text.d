.sv-build/linux/8c1ae82935084694898c/ui/message-text.o: \
  client/sv/ui/message-text.c client/sv/ui/message-text.h \
  client/sv/session/session.h client/sv/result.h
client/sv/ui/message-text.h:
client/sv/session/session.h:
client/sv/result.h:
