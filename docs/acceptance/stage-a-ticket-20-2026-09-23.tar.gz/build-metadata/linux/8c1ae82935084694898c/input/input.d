.sv-build/linux/8c1ae82935084694898c/input/input.o: \
  client/sv/input/input.c client/sv/input/input.h \
  client/sv/session/session.h client/sv/result.h
client/sv/input/input.h:
client/sv/session/session.h:
client/sv/result.h:
