.sv-build/linux/8c1ae82935084694898c/input/native-input.o: \
  client/sv/input/native-input.c client/sv/input/native-input.h \
  client/sv/app.h client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h
client/sv/input/native-input.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
