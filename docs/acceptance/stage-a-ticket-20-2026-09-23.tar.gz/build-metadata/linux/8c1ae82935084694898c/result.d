.sv-build/linux/8c1ae82935084694898c/result.o: client/sv/result.c \
  client/sv/result.h
client/sv/result.h:
