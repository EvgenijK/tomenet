.sv-build/linux/8c1ae82935084694898c/diagnostics/timing.o: \
  client/sv/diagnostics/timing.c client/sv/diagnostics/timing.h \
  client/sv/ui/ui.h client/sv/ui/font.h client/sv/ui/status.h \
  client/sv/app.h client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h client/sv/ui/message-text.h
client/sv/diagnostics/timing.h:
client/sv/ui/ui.h:
client/sv/ui/font.h:
client/sv/ui/status.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/ui/message-text.h:
