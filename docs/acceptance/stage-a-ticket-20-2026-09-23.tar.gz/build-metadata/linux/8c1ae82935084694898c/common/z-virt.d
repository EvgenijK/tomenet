.sv-build/linux/8c1ae82935084694898c/common/z-virt.o: common/z-virt.c \
  common/z-virt.h common/h-basic.h common/../h-config.h \
  common/h-system.h common/h-type.h common/h-define.h common/h-net.h \
  common/sockbuf.h common/net-unix.h common/pack.h common/bit.h \
  common/z-util.h
common/z-virt.h:
common/h-basic.h:
common/../h-config.h:
common/h-system.h:
common/h-type.h:
common/h-define.h:
common/h-net.h:
common/sockbuf.h:
common/net-unix.h:
common/pack.h:
common/bit.h:
common/z-util.h:
