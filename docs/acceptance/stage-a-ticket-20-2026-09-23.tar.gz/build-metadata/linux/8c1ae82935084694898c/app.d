.sv-build/linux/8c1ae82935084694898c/app.o: client/sv/app.c \
  client/sv/app.h client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h \
  client/sv/protocol/protocol.h
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/protocol/protocol.h:
