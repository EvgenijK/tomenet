.sv-build/linux/d40b159e6018a2bbe18e/hp-scenario.o: \
  client/sv/hp-scenario.c client/sv/hp-scenario.h client/sv/session.h \
  client/sv/status.h
client/sv/hp-scenario.h:
client/sv/session.h:
client/sv/status.h:
