.sv-build/linux/d40b159e6018a2bbe18e/main.o: client/sv/main.c \
  client/sv/font.h client/sv/session.h client/sv/status.h \
  client/sv/hp-scenario.h
client/sv/font.h:
client/sv/session.h:
client/sv/status.h:
client/sv/hp-scenario.h:
