.sv-build/linux/d40b159e6018a2bbe18e/common/z-util.o: common/z-util.c \
  common/z-util.h common/h-basic.h common/../h-config.h \
  common/h-system.h common/h-type.h common/h-define.h common/h-net.h \
  common/sockbuf.h common/net-unix.h common/pack.h common/bit.h \
  common/z-form.h
common/z-util.h:
common/h-basic.h:
common/../h-config.h:
common/h-system.h:
common/h-type.h:
common/h-define.h:
common/h-net.h:
common/sockbuf.h:
common/net-unix.h:
common/pack.h:
common/bit.h:
common/z-form.h:
