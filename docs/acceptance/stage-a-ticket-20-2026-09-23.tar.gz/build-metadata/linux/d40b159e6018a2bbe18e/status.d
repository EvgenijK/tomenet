.sv-build/linux/d40b159e6018a2bbe18e/status.o: client/sv/status.c \
  client/sv/status.h client/sv/session.h
client/sv/status.h:
client/sv/session.h:
