.sv-build/linux/ebab0e4c4e0c5655dfdd/common/common.o: common/common.c \
  common/angband.h common/../common/h-basic.h \
  common/../common/../h-config.h common/../common/h-system.h \
  common/../common/h-type.h common/../common/h-define.h \
  common/../common/h-net.h common/../common/sockbuf.h \
  common/../common/net-unix.h common/../common/pack.h \
  common/../common/bit.h common/../common/z-util.h \
  common/../common/z-virt.h common/../common/z-form.h \
  common/../common/z-rand.h common/z-term.h common/h-basic.h \
  common/../config.h common/../common/defines.h \
  common/../common/defines-local.h common/../common/defines-features.h \
  common/../common/defines-features-local.h common/../common/colours.h \
  common/../server/quests-defines.h common/../common/types.h \
  common/externs.h
common/angband.h:
common/../common/h-basic.h:
common/../common/../h-config.h:
common/../common/h-system.h:
common/../common/h-type.h:
common/../common/h-define.h:
common/../common/h-net.h:
common/../common/sockbuf.h:
common/../common/net-unix.h:
common/../common/pack.h:
common/../common/bit.h:
common/../common/z-util.h:
common/../common/z-virt.h:
common/../common/z-form.h:
common/../common/z-rand.h:
common/z-term.h:
common/h-basic.h:
common/../config.h:
common/../common/defines.h:
common/../common/defines-local.h:
common/../common/defines-features.h:
common/../common/defines-features-local.h:
common/../common/colours.h:
common/../server/quests-defines.h:
common/../common/types.h:
common/externs.h:
