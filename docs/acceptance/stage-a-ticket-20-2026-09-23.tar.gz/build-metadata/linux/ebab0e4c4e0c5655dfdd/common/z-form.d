.sv-build/linux/ebab0e4c4e0c5655dfdd/common/z-form.o: common/z-form.c \
  common/z-form.h common/h-basic.h common/../h-config.h \
  common/h-system.h common/h-type.h common/h-define.h common/h-net.h \
  common/sockbuf.h common/net-unix.h common/pack.h common/bit.h \
  common/z-util.h common/z-virt.h
common/z-form.h:
common/h-basic.h:
common/../h-config.h:
common/h-system.h:
common/h-type.h:
common/h-define.h:
common/h-net.h:
common/sockbuf.h:
common/net-unix.h:
common/pack.h:
common/bit.h:
common/z-util.h:
common/z-virt.h:
