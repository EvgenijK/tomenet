.sv-build/linux/ebab0e4c4e0c5655dfdd/peer.o: client/sv/peer.c \
  client/sv/../../common/angband.h \
  client/sv/../../common/../common/h-basic.h \
  client/sv/../../common/../common/../h-config.h \
  client/sv/../../common/../common/h-system.h \
  client/sv/../../common/../common/h-type.h \
  client/sv/../../common/../common/h-define.h \
  client/sv/../../common/../common/h-net.h \
  client/sv/../../common/../common/sockbuf.h \
  client/sv/../../common/../common/net-unix.h \
  client/sv/../../common/../common/pack.h \
  client/sv/../../common/../common/bit.h \
  client/sv/../../common/../common/z-util.h \
  client/sv/../../common/../common/z-virt.h \
  client/sv/../../common/../common/z-form.h \
  client/sv/../../common/../common/z-rand.h \
  client/sv/../../common/z-term.h client/sv/../../common/h-basic.h \
  client/sv/../../common/../config.h \
  client/sv/../../common/../common/defines.h \
  client/sv/../../common/../common/defines-local.h \
  client/sv/../../common/../common/defines-features.h \
  client/sv/../../common/../common/defines-features-local.h \
  client/sv/../../common/../common/colours.h \
  client/sv/../../common/../server/quests-defines.h \
  client/sv/../../common/../common/types.h \
  client/sv/../../common/externs.h
client/sv/../../common/angband.h:
client/sv/../../common/../common/h-basic.h:
client/sv/../../common/../common/../h-config.h:
client/sv/../../common/../common/h-system.h:
client/sv/../../common/../common/h-type.h:
client/sv/../../common/../common/h-define.h:
client/sv/../../common/../common/h-net.h:
client/sv/../../common/../common/sockbuf.h:
client/sv/../../common/../common/net-unix.h:
client/sv/../../common/../common/pack.h:
client/sv/../../common/../common/bit.h:
client/sv/../../common/../common/z-util.h:
client/sv/../../common/../common/z-virt.h:
client/sv/../../common/../common/z-form.h:
client/sv/../../common/../common/z-rand.h:
client/sv/../../common/z-term.h:
client/sv/../../common/h-basic.h:
client/sv/../../common/../config.h:
client/sv/../../common/../common/defines.h:
client/sv/../../common/../common/defines-local.h:
client/sv/../../common/../common/defines-features.h:
client/sv/../../common/../common/defines-features-local.h:
client/sv/../../common/../common/colours.h:
client/sv/../../common/../server/quests-defines.h:
client/sv/../../common/../common/types.h:
client/sv/../../common/externs.h:
