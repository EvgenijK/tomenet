.sv-build/linux/ebab0e4c4e0c5655dfdd/main.o: client/sv/main.c \
  client/sv/font.h client/sv/session.h client/sv/hp-scenario.h
client/sv/font.h:
client/sv/session.h:
client/sv/hp-scenario.h:
