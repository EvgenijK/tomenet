.sv-build/linux/ebab0e4c4e0c5655dfdd/hp-scenario.o: \
  client/sv/hp-scenario.c client/sv/hp-scenario.h client/sv/session.h
client/sv/hp-scenario.h:
client/sv/session.h:
