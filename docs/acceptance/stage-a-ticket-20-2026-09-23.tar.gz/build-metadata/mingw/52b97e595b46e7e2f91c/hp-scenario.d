.sv-build/mingw/52b97e595b46e7e2f91c/hp-scenario.o: \
 client/sv/hp-scenario.c client/sv/hp-scenario.h client/sv/session.h
client/sv/hp-scenario.h:
client/sv/session.h:
