.sv-build/mingw/614ce1f5168bd6c1aa5c/session/alerts.o: \
 client/sv/session/alerts.c client/sv/session/alerts.h \
 client/sv/session/session.h client/sv/result.h
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
