.sv-build/mingw/614ce1f5168bd6c1aa5c/ui/status.o: client/sv/ui/status.c \
 client/sv/ui/status.h client/sv/app.h client/sv/session/alerts.h \
 client/sv/session/session.h client/sv/result.h client/sv/result.h \
 client/sv/input/input.h
client/sv/ui/status.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/result.h:
client/sv/input/input.h:
