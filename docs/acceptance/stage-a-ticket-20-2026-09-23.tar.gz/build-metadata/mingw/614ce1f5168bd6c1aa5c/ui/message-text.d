.sv-build/mingw/614ce1f5168bd6c1aa5c/ui/message-text.o: \
 client/sv/ui/message-text.c client/sv/ui/message-text.h \
 client/sv/session/session.h client/sv/result.h
client/sv/ui/message-text.h:
client/sv/session/session.h:
client/sv/result.h:
