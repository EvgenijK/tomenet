.sv-build/mingw/614ce1f5168bd6c1aa5c/app.o: client/sv/app.c \
 client/sv/app.h client/sv/session/alerts.h client/sv/session/session.h \
 client/sv/result.h client/sv/result.h client/sv/input/input.h \
 client/sv/protocol/protocol.h
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/protocol/protocol.h:
