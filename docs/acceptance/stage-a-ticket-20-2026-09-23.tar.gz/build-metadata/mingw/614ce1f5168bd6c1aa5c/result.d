.sv-build/mingw/614ce1f5168bd6c1aa5c/result.o: client/sv/result.c \
 client/sv/result.h
client/sv/result.h:
