.sv-build/mingw/614ce1f5168bd6c1aa5c/input/input.o: \
 client/sv/input/input.c client/sv/input/input.h \
 client/sv/session/session.h client/sv/result.h
client/sv/input/input.h:
client/sv/session/session.h:
client/sv/result.h:
