.sv-build/mingw/614ce1f5168bd6c1aa5c/protocol/protocol.o: \
 client/sv/protocol/protocol.c \
 client/sv/protocol/../../../common/angband.h \
 client/sv/protocol/../../../common/../common/h-basic.h \
 client/sv/protocol/../../../common/../common/../h-config.h \
 client/sv/protocol/../../../common/../common/h-system.h \
 client/sv/protocol/../../../common/../common/h-type.h \
 client/sv/protocol/../../../common/../common/h-define.h \
 client/sv/protocol/../../../common/../common/h-net.h \
 client/sv/protocol/../../../common/../common/sockbuf.h \
 client/sv/protocol/../../../common/../common/net-win.h \
 client/sv/protocol/../../../common/../common/pack.h \
 client/sv/protocol/../../../common/../common/bit.h \
 client/sv/protocol/../../../common/../common/z-util.h \
 client/sv/protocol/../../../common/../common/h-basic.h \
 client/sv/protocol/../../../common/../common/z-virt.h \
 client/sv/protocol/../../../common/../common/z-form.h \
 client/sv/protocol/../../../common/../common/z-rand.h \
 client/sv/protocol/../../../common/z-term.h \
 client/sv/protocol/../../../common/h-basic.h \
 client/sv/protocol/../../../common/../config.h \
 client/sv/protocol/../../../common/../common/defines.h \
 client/sv/protocol/../../../common/../common/defines-local.h \
 client/sv/protocol/../../../common/../common/defines-features.h \
 client/sv/protocol/../../../common/../common/defines-features-local.h \
 client/sv/protocol/../../../common/../common/colours.h \
 client/sv/protocol/../../../common/../server/quests-defines.h \
 client/sv/protocol/../../../common/../common/types.h \
 client/sv/protocol/../../../common/externs.h \
 client/sv/protocol/../../../common/sockbuf.h \
 client/sv/protocol/../../../common/pack.h client/sv/protocol/hp-update.h \
 client/sv/protocol/message-update.h client/sv/protocol/key-request.h \
 client/sv/protocol/protocol.h client/sv/result.h \
 client/sv/session/session.h
client/sv/protocol/../../../common/angband.h:
client/sv/protocol/../../../common/../common/h-basic.h:
client/sv/protocol/../../../common/../common/../h-config.h:
client/sv/protocol/../../../common/../common/h-system.h:
client/sv/protocol/../../../common/../common/h-type.h:
client/sv/protocol/../../../common/../common/h-define.h:
client/sv/protocol/../../../common/../common/h-net.h:
client/sv/protocol/../../../common/../common/sockbuf.h:
client/sv/protocol/../../../common/../common/net-win.h:
client/sv/protocol/../../../common/../common/pack.h:
client/sv/protocol/../../../common/../common/bit.h:
client/sv/protocol/../../../common/../common/z-util.h:
client/sv/protocol/../../../common/../common/h-basic.h:
client/sv/protocol/../../../common/../common/z-virt.h:
client/sv/protocol/../../../common/../common/z-form.h:
client/sv/protocol/../../../common/../common/z-rand.h:
client/sv/protocol/../../../common/z-term.h:
client/sv/protocol/../../../common/h-basic.h:
client/sv/protocol/../../../common/../config.h:
client/sv/protocol/../../../common/../common/defines.h:
client/sv/protocol/../../../common/../common/defines-local.h:
client/sv/protocol/../../../common/../common/defines-features.h:
client/sv/protocol/../../../common/../common/defines-features-local.h:
client/sv/protocol/../../../common/../common/colours.h:
client/sv/protocol/../../../common/../server/quests-defines.h:
client/sv/protocol/../../../common/../common/types.h:
client/sv/protocol/../../../common/externs.h:
client/sv/protocol/../../../common/sockbuf.h:
client/sv/protocol/../../../common/pack.h:
client/sv/protocol/hp-update.h:
client/sv/protocol/message-update.h:
client/sv/protocol/key-request.h:
client/sv/protocol/protocol.h:
client/sv/result.h:
client/sv/session/session.h:
