.sv-build/mingw/614ce1f5168bd6c1aa5c/main.o: client/sv/main.c \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_stdinc.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_platform_defines.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_begin_code.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_close_code.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_assert.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_asyncio.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_atomic.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_audio.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_endian.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_error.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_mutex.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_thread.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_properties.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_iostream.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_bits.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_blendmode.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_camera.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_pixels.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_surface.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_rect.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_clipboard.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_cpuinfo.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_dialog.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_video.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_dlopennote.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_events.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_gamepad.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_guid.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_joystick.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_power.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_sensor.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_keyboard.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_keycode.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_scancode.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_mouse.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_pen.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_touch.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_filesystem.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_gpu.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_haptic.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_hidapi.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_hints.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_init.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_loadso.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_locale.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_log.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_messagebox.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_metal.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_misc.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_platform.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_process.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_render.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_storage.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_system.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_time.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_timer.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_tray.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_version.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_oldnames.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_main.h \
 /tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_main_impl.h \
 /tmp/sv16-sdk-final/SDL3_ttf-3.2.2/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3_ttf/SDL_ttf.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/ft2build.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/ftheader.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/freetype.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/ftconfig.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/ftoption.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/ftstdlib.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/integer-types.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/public-macros.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/mac-support.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/fttypes.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/ftsystem.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/ftimage.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/fterrors.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/ftmoderr.h \
 /tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/fterrdef.h \
 client/sv/ui/font.h client/sv/session/session.h client/sv/result.h \
 client/sv/ui/status.h client/sv/app.h client/sv/session/alerts.h \
 client/sv/session/session.h client/sv/result.h client/sv/input/input.h \
 client/sv/ui/ui.h client/sv/ui/font.h client/sv/ui/status.h \
 client/sv/ui/message-text.h ../tests/sv/scenarios/hp-scenario.h \
 ../tests/sv/scenarios/message-scenario.h client/sv/ui/ui.h \
 ../tests/sv/scenarios/request-scenario.h \
 ../tests/sv/scenarios/lifecycle-scenario.h \
 client/sv/input/native-input.h ../tests/sv/scenarios/geometry-scenario.h \
 ../tests/sv/scenarios/timing-scenario.h \
 ../tests/sv/scenarios/arch-scenario.h \
 ../tests/sv/scenarios/hp-scenario.h ../tests/sv/scenarios/native-frame.h \
 temporary/sv/synthetic.h
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_stdinc.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_platform_defines.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_begin_code.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_close_code.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_assert.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_asyncio.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_atomic.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_audio.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_endian.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_error.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_mutex.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_thread.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_properties.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_iostream.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_bits.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_blendmode.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_camera.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_pixels.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_surface.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_rect.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_clipboard.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_cpuinfo.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_dialog.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_video.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_dlopennote.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_events.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_gamepad.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_guid.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_joystick.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_power.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_sensor.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_keyboard.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_keycode.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_scancode.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_mouse.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_pen.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_touch.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_filesystem.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_gpu.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_haptic.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_hidapi.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_hints.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_init.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_loadso.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_locale.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_log.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_messagebox.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_metal.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_misc.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_platform.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_process.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_render.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_storage.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_system.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_time.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_timer.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_tray.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_version.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_oldnames.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_main.h:
/tmp/sv16-sdk-final/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_main_impl.h:
/tmp/sv16-sdk-final/SDL3_ttf-3.2.2/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3_ttf/SDL_ttf.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/ft2build.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/ftheader.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/freetype.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/ftconfig.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/ftoption.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/ftstdlib.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/integer-types.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/public-macros.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/config/mac-support.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/fttypes.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/ftsystem.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/ftimage.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/fterrors.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/ftmoderr.h:
/tmp/sv16-sdk-final/freetype-i686/lib/pkgconfig/../../include/freetype2/freetype/fterrdef.h:
client/sv/ui/font.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/ui/status.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/ui/ui.h:
client/sv/ui/font.h:
client/sv/ui/status.h:
client/sv/ui/message-text.h:
../tests/sv/scenarios/hp-scenario.h:
../tests/sv/scenarios/message-scenario.h:
client/sv/ui/ui.h:
../tests/sv/scenarios/request-scenario.h:
../tests/sv/scenarios/lifecycle-scenario.h:
client/sv/input/native-input.h:
../tests/sv/scenarios/geometry-scenario.h:
../tests/sv/scenarios/timing-scenario.h:
../tests/sv/scenarios/arch-scenario.h:
../tests/sv/scenarios/hp-scenario.h:
../tests/sv/scenarios/native-frame.h:
temporary/sv/synthetic.h:
