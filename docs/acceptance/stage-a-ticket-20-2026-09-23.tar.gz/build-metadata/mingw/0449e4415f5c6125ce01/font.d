.sv-build/mingw/0449e4415f5c6125ce01/font.o: client/sv/font.c \
 client/sv/font.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_stdinc.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_platform_defines.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_begin_code.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_close_code.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_assert.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_asyncio.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_atomic.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_audio.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_endian.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_error.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_mutex.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_thread.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_properties.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_iostream.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_bits.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_blendmode.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_camera.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_pixels.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_surface.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_rect.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_clipboard.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_cpuinfo.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_dialog.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_video.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_dlopennote.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_events.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_gamepad.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_guid.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_joystick.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_power.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_sensor.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_keyboard.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_keycode.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_scancode.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_mouse.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_pen.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_touch.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_filesystem.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_gpu.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_haptic.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_hidapi.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_hints.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_init.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_loadso.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_locale.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_log.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_messagebox.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_metal.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_misc.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_platform.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_process.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_render.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_storage.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_system.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_time.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_timer.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_tray.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_version.h \
 /tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_oldnames.h \
 /tmp/sv-sdk/SDL3_ttf-3.2.2/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3_ttf/SDL_ttf.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/ft2build.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/ftheader.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/freetype.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/ftconfig.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/ftoption.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/ftstdlib.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/integer-types.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/public-macros.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/mac-support.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/fttypes.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/ftsystem.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/ftimage.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/fterrors.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/ftmoderr.h \
 /tmp/sv-sdk/freetype-i686/include/freetype2/freetype/fterrdef.h
client/sv/font.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_stdinc.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_platform_defines.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_begin_code.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_close_code.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_assert.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_asyncio.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_atomic.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_audio.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_endian.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_error.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_mutex.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_thread.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_properties.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_iostream.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_bits.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_blendmode.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_camera.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_pixels.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_surface.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_rect.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_clipboard.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_cpuinfo.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_dialog.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_video.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_dlopennote.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_events.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_gamepad.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_guid.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_joystick.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_power.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_sensor.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_keyboard.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_keycode.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_scancode.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_mouse.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_pen.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_touch.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_filesystem.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_gpu.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_haptic.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_hidapi.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_hints.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_init.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_loadso.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_locale.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_log.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_messagebox.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_metal.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_misc.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_platform.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_process.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_render.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_storage.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_system.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_time.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_timer.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_tray.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_version.h:
/tmp/sv-sdk/SDL3-3.4.0/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3/SDL_oldnames.h:
/tmp/sv-sdk/SDL3_ttf-3.2.2/i686-w64-mingw32/lib/pkgconfig/../../include/SDL3_ttf/SDL_ttf.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/ft2build.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/ftheader.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/freetype.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/ftconfig.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/ftoption.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/ftstdlib.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/integer-types.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/public-macros.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/config/mac-support.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/fttypes.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/ftsystem.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/ftimage.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/fterrors.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/ftmoderr.h:
/tmp/sv-sdk/freetype-i686/include/freetype2/freetype/fterrdef.h:
