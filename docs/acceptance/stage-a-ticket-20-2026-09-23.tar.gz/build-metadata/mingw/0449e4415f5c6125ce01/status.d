.sv-build/mingw/0449e4415f5c6125ce01/status.o: client/sv/status.c \
 client/sv/status.h client/sv/session.h
client/sv/status.h:
client/sv/session.h:
