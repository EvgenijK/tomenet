.sv-build/mingw/ba92559ec470a178cd0f/session/alerts.o: \
 client/sv/session/alerts.c client/sv/session/alerts.h \
 client/sv/session/session.h client/sv/result.h
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
