.sv-build/mingw/ba92559ec470a178cd0f/ui/message-text.o: \
 client/sv/ui/message-text.c client/sv/ui/message-text.h \
 client/sv/session/session.h client/sv/result.h
client/sv/ui/message-text.h:
client/sv/session/session.h:
client/sv/result.h:
