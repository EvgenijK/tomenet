.sv-build/mingw/ba92559ec470a178cd0f/result.o: client/sv/result.c \
 client/sv/result.h
client/sv/result.h:
