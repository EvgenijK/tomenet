.sv-build/mingw/ba92559ec470a178cd0f/input/input.o: \
 client/sv/input/input.c client/sv/input/input.h \
 client/sv/session/session.h client/sv/result.h
client/sv/input/input.h:
client/sv/session/session.h:
client/sv/result.h:
