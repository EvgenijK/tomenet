.sv-build/mingw/ba92559ec470a178cd0f/temporary/peer.o: \
 temporary/sv/peer.c temporary/sv/../../common/angband.h \
 temporary/sv/../../common/../common/h-basic.h \
 temporary/sv/../../common/../common/../h-config.h \
 temporary/sv/../../common/../common/h-system.h \
 temporary/sv/../../common/../common/h-type.h \
 temporary/sv/../../common/../common/h-define.h \
 temporary/sv/../../common/../common/h-net.h \
 temporary/sv/../../common/../common/sockbuf.h \
 temporary/sv/../../common/../common/net-win.h \
 temporary/sv/../../common/../common/pack.h \
 temporary/sv/../../common/../common/bit.h \
 temporary/sv/../../common/../common/z-util.h \
 temporary/sv/../../common/../common/h-basic.h \
 temporary/sv/../../common/../common/z-virt.h \
 temporary/sv/../../common/../common/z-form.h \
 temporary/sv/../../common/../common/z-rand.h \
 temporary/sv/../../common/z-term.h temporary/sv/../../common/h-basic.h \
 temporary/sv/../../common/../config.h \
 temporary/sv/../../common/../common/defines.h \
 temporary/sv/../../common/../common/defines-local.h \
 temporary/sv/../../common/../common/defines-features.h \
 temporary/sv/../../common/../common/defines-features-local.h \
 temporary/sv/../../common/../common/colours.h \
 temporary/sv/../../common/../server/quests-defines.h \
 temporary/sv/../../common/../common/types.h \
 temporary/sv/../../common/externs.h
temporary/sv/../../common/angband.h:
temporary/sv/../../common/../common/h-basic.h:
temporary/sv/../../common/../common/../h-config.h:
temporary/sv/../../common/../common/h-system.h:
temporary/sv/../../common/../common/h-type.h:
temporary/sv/../../common/../common/h-define.h:
temporary/sv/../../common/../common/h-net.h:
temporary/sv/../../common/../common/sockbuf.h:
temporary/sv/../../common/../common/net-win.h:
temporary/sv/../../common/../common/pack.h:
temporary/sv/../../common/../common/bit.h:
temporary/sv/../../common/../common/z-util.h:
temporary/sv/../../common/../common/h-basic.h:
temporary/sv/../../common/../common/z-virt.h:
temporary/sv/../../common/../common/z-form.h:
temporary/sv/../../common/../common/z-rand.h:
temporary/sv/../../common/z-term.h:
temporary/sv/../../common/h-basic.h:
temporary/sv/../../common/../config.h:
temporary/sv/../../common/../common/defines.h:
temporary/sv/../../common/../common/defines-local.h:
temporary/sv/../../common/../common/defines-features.h:
temporary/sv/../../common/../common/defines-features-local.h:
temporary/sv/../../common/../common/colours.h:
temporary/sv/../../common/../server/quests-defines.h:
temporary/sv/../../common/../common/types.h:
temporary/sv/../../common/externs.h:
