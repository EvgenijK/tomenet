.sv-build/mingw/fda94f525612adf29445/hp-scenario.o: \
 client/sv/hp-scenario.c client/sv/hp-scenario.h client/sv/session.h \
 client/sv/status.h
client/sv/hp-scenario.h:
client/sv/session.h:
client/sv/status.h:
