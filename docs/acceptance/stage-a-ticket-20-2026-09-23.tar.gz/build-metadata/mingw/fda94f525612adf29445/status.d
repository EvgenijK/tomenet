.sv-build/mingw/fda94f525612adf29445/status.o: client/sv/status.c \
 client/sv/status.h client/sv/session.h
client/sv/status.h:
client/sv/session.h:
