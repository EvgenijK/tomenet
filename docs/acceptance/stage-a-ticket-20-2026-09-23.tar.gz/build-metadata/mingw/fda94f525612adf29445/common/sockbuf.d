.sv-build/mingw/fda94f525612adf29445/common/sockbuf.o: common/sockbuf.c \
 common/angband.h common/../common/h-basic.h \
 common/../common/../h-config.h common/../common/h-system.h \
 common/../common/h-type.h common/../common/h-define.h \
 common/../common/h-net.h common/../common/sockbuf.h \
 common/../common/net-win.h common/../common/pack.h \
 common/../common/bit.h common/../common/z-util.h \
 common/../common/h-basic.h common/../common/z-virt.h \
 common/../common/z-form.h common/../common/z-rand.h common/z-term.h \
 common/h-basic.h common/../config.h common/../common/defines.h \
 common/../common/defines-local.h common/../common/defines-features.h \
 common/../common/defines-features-local.h common/../common/colours.h \
 common/../server/quests-defines.h common/../common/types.h \
 common/externs.h common/version.h common/const.h common/sockbuf.h \
 common/pack.h common/bit.h common/net-win.h
common/angband.h:
common/../common/h-basic.h:
common/../common/../h-config.h:
common/../common/h-system.h:
common/../common/h-type.h:
common/../common/h-define.h:
common/../common/h-net.h:
common/../common/sockbuf.h:
common/../common/net-win.h:
common/../common/pack.h:
common/../common/bit.h:
common/../common/z-util.h:
common/../common/h-basic.h:
common/../common/z-virt.h:
common/../common/z-form.h:
common/../common/z-rand.h:
common/z-term.h:
common/h-basic.h:
common/../config.h:
common/../common/defines.h:
common/../common/defines-local.h:
common/../common/defines-features.h:
common/../common/defines-features-local.h:
common/../common/colours.h:
common/../server/quests-defines.h:
common/../common/types.h:
common/externs.h:
common/version.h:
common/const.h:
common/sockbuf.h:
common/pack.h:
common/bit.h:
common/net-win.h:
