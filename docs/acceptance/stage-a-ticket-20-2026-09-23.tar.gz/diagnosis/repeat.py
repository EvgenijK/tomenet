import hashlib,json,os,subprocess,time
from pathlib import Path
out=Path('/tmp/sv20-independent');out.mkdir()
prefix=out/'wine-prefix';prefix.mkdir()
env=dict(os.environ,WINEPREFIX=str(prefix),WINEDEBUG='-all')
rows=[]
def run(name,cmd):
    start=time.monotonic()
    with (out/(name+'.log')).open('w') as f:
        result=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    rows.append(dict(name=name,command=cmd,returncode=result.returncode,seconds=time.monotonic()-start))
    (out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(name,result.returncode,flush=True)
run('wine-version',['wine','--version'])
run('wineboot',['wineboot','-u'])
for i in range(3):
    run('timing-'+str(i+1),['/tmp/sv15-venv/bin/python','-B','tests/sv_timing_native.py','--wine','--backend','direct3d','--binary','/tmp/sv20-final-bin/tomenet-sv.exe'])
