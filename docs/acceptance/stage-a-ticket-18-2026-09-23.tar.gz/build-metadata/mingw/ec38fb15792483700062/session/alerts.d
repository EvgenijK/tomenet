.sv-build/mingw/ec38fb15792483700062/session/alerts.o: \
 client/sv/session/alerts.c client/sv/session/alerts.h \
 client/sv/session/session.h client/sv/result.h
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
