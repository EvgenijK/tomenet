.sv-build/mingw/ec38fb15792483700062/input/input.o: \
 client/sv/input/input.c client/sv/input/input.h \
 client/sv/session/session.h client/sv/result.h
client/sv/input/input.h:
client/sv/session/session.h:
client/sv/result.h:
