.sv-build/mingw/ec38fb15792483700062/result.o: client/sv/result.c \
 client/sv/result.h
client/sv/result.h:
