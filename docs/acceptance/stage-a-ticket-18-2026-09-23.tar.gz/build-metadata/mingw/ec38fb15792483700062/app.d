.sv-build/mingw/ec38fb15792483700062/app.o: client/sv/app.c \
 client/sv/app.h client/sv/session/alerts.h client/sv/session/session.h \
 client/sv/result.h client/sv/result.h client/sv/input/input.h \
 client/sv/diagnostics/runtime.h client/sv/protocol/protocol.h
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/diagnostics/runtime.h:
client/sv/protocol/protocol.h:
