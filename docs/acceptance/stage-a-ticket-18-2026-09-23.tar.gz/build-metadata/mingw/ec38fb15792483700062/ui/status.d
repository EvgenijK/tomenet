.sv-build/mingw/ec38fb15792483700062/ui/status.o: client/sv/ui/status.c \
 client/sv/ui/status.h client/sv/app.h client/sv/session/alerts.h \
 client/sv/session/session.h client/sv/result.h client/sv/result.h \
 client/sv/input/input.h client/sv/diagnostics/runtime.h
client/sv/ui/status.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/diagnostics/runtime.h:
