.sv-build/mingw/ec38fb15792483700062/ui/message-text.o: \
 client/sv/ui/message-text.c client/sv/ui/message-text.h \
 client/sv/session/session.h client/sv/result.h
client/sv/ui/message-text.h:
client/sv/session/session.h:
client/sv/result.h:
