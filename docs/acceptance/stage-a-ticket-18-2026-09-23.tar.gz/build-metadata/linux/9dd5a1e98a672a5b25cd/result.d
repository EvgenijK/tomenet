.sv-build/linux/9dd5a1e98a672a5b25cd/result.o: client/sv/result.c \
  client/sv/result.h
client/sv/result.h:
