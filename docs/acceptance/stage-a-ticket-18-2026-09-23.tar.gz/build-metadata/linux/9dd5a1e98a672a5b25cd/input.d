.sv-build/linux/9dd5a1e98a672a5b25cd/input.o: client/sv/input.c \
  client/sv/input.h client/sv/session.h client/sv/result.h
client/sv/input.h:
client/sv/session.h:
client/sv/result.h:
