.sv-build/linux/9dd5a1e98a672a5b25cd/timing.o: client/sv/timing.c \
  client/sv/timing.h client/sv/ui.h client/sv/font.h client/sv/status.h \
  client/sv/app.h client/sv/alerts.h client/sv/session.h \
  client/sv/result.h client/sv/input.h client/sv/message-text.h
client/sv/timing.h:
client/sv/ui.h:
client/sv/font.h:
client/sv/status.h:
client/sv/app.h:
client/sv/alerts.h:
client/sv/session.h:
client/sv/result.h:
client/sv/input.h:
client/sv/message-text.h:
