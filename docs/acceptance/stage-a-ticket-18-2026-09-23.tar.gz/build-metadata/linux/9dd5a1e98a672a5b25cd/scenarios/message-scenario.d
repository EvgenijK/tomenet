.sv-build/linux/9dd5a1e98a672a5b25cd/scenarios/message-scenario.o: \
  ../tests/sv/scenarios/message-scenario.c \
  ../tests/sv/scenarios/message-scenario.h client/sv/ui/ui.h \
  client/sv/ui/font.h client/sv/ui/status.h client/sv/app.h \
  client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h \
  client/sv/diagnostics/runtime.h client/sv/ui/message-text.h \
  ../tests/sv/scenarios/native-frame.h
../tests/sv/scenarios/message-scenario.h:
client/sv/ui/ui.h:
client/sv/ui/font.h:
client/sv/ui/status.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/diagnostics/runtime.h:
client/sv/ui/message-text.h:
../tests/sv/scenarios/native-frame.h:
