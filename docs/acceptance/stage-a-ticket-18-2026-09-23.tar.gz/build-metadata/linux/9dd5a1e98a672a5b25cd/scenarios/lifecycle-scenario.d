.sv-build/linux/9dd5a1e98a672a5b25cd/scenarios/lifecycle-scenario.o: \
  ../tests/sv/scenarios/lifecycle-scenario.c \
  ../tests/sv/scenarios/lifecycle-scenario.h client/sv/ui/ui.h \
  client/sv/ui/font.h client/sv/ui/status.h client/sv/app.h \
  client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h \
  client/sv/diagnostics/runtime.h client/sv/ui/message-text.h \
  client/sv/input/native-input.h ../tests/sv/scenarios/native-frame.h
../tests/sv/scenarios/lifecycle-scenario.h:
client/sv/ui/ui.h:
client/sv/ui/font.h:
client/sv/ui/status.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/diagnostics/runtime.h:
client/sv/ui/message-text.h:
client/sv/input/native-input.h:
../tests/sv/scenarios/native-frame.h:
