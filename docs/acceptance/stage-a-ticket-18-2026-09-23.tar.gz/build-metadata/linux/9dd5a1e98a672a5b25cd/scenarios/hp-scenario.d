.sv-build/linux/9dd5a1e98a672a5b25cd/scenarios/hp-scenario.o: \
  ../tests/sv/scenarios/hp-scenario.c \
  ../tests/sv/scenarios/hp-scenario.h client/sv/app.h \
  client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h \
  client/sv/diagnostics/runtime.h client/sv/ui/status.h
../tests/sv/scenarios/hp-scenario.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/diagnostics/runtime.h:
client/sv/ui/status.h:
