.sv-build/linux/9dd5a1e98a672a5b25cd/input/native-input.o: \
  client/sv/input/native-input.c client/sv/input/native-input.h \
  client/sv/app.h client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h \
  client/sv/diagnostics/runtime.h
client/sv/input/native-input.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/diagnostics/runtime.h:
