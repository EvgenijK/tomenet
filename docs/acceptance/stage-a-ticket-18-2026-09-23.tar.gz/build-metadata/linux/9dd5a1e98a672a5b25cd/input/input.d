.sv-build/linux/9dd5a1e98a672a5b25cd/input/input.o: \
  client/sv/input/input.c client/sv/input/input.h \
  client/sv/session/session.h client/sv/result.h
client/sv/input/input.h:
client/sv/session/session.h:
client/sv/result.h:
