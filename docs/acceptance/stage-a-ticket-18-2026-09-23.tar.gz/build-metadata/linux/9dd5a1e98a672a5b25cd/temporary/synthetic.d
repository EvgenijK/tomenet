.sv-build/linux/9dd5a1e98a672a5b25cd/temporary/synthetic.o: \
  temporary/sv/synthetic.c temporary/sv/synthetic.h client/sv/app.h \
  client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h \
  client/sv/diagnostics/runtime.h
temporary/sv/synthetic.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/diagnostics/runtime.h:
