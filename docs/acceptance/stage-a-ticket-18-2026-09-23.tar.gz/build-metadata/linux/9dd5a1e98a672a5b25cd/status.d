.sv-build/linux/9dd5a1e98a672a5b25cd/status.o: client/sv/status.c \
  client/sv/status.h client/sv/app.h client/sv/alerts.h \
  client/sv/session.h client/sv/result.h client/sv/input.h
client/sv/status.h:
client/sv/app.h:
client/sv/alerts.h:
client/sv/session.h:
client/sv/result.h:
client/sv/input.h:
