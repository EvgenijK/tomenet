.sv-build/linux/9dd5a1e98a672a5b25cd/native-input.o: \
  client/sv/native-input.c client/sv/native-input.h client/sv/app.h \
  client/sv/alerts.h client/sv/session.h client/sv/result.h \
  client/sv/input.h
client/sv/native-input.h:
client/sv/app.h:
client/sv/alerts.h:
client/sv/session.h:
client/sv/result.h:
client/sv/input.h:
