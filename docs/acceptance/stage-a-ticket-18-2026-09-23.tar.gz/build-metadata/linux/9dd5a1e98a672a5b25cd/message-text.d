.sv-build/linux/9dd5a1e98a672a5b25cd/message-text.o: \
  client/sv/message-text.c client/sv/message-text.h client/sv/session.h \
  client/sv/result.h
client/sv/message-text.h:
client/sv/session.h:
client/sv/result.h:
