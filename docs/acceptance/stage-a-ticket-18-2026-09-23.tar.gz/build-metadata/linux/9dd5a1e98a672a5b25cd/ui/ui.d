.sv-build/linux/9dd5a1e98a672a5b25cd/ui/ui.o: client/sv/ui/ui.c \
  client/sv/ui/ui.h client/sv/ui/font.h client/sv/ui/status.h \
  client/sv/app.h client/sv/session/alerts.h client/sv/session/session.h \
  client/sv/result.h client/sv/input/input.h \
  client/sv/diagnostics/runtime.h client/sv/ui/message-text.h
client/sv/ui/ui.h:
client/sv/ui/font.h:
client/sv/ui/status.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/input/input.h:
client/sv/diagnostics/runtime.h:
client/sv/ui/message-text.h:
