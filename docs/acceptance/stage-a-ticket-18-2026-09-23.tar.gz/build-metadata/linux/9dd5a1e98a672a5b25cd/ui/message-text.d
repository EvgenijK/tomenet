.sv-build/linux/9dd5a1e98a672a5b25cd/ui/message-text.o: \
  client/sv/ui/message-text.c client/sv/ui/message-text.h \
  client/sv/session/session.h client/sv/result.h
client/sv/ui/message-text.h:
client/sv/session/session.h:
client/sv/result.h:
