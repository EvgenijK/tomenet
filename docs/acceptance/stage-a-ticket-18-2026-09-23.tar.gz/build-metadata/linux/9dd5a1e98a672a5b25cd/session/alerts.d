.sv-build/linux/9dd5a1e98a672a5b25cd/session/alerts.o: \
  client/sv/session/alerts.c client/sv/session/alerts.h \
  client/sv/session/session.h client/sv/result.h
client/sv/session/alerts.h:
client/sv/session/session.h:
client/sv/result.h:
