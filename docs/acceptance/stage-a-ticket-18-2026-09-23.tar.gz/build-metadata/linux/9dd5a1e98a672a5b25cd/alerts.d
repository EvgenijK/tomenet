.sv-build/linux/9dd5a1e98a672a5b25cd/alerts.o: client/sv/alerts.c \
  client/sv/alerts.h client/sv/session.h client/sv/result.h
client/sv/alerts.h:
client/sv/session.h:
client/sv/result.h:
