.sv-build/linux/9dd5a1e98a672a5b25cd/main.o: client/sv/main.c \
  /usr/include/freetype2/ft2build.h \
  /usr/include/freetype2/freetype/config/ftheader.h \
  /usr/include/freetype2/freetype/freetype.h \
  /usr/include/freetype2/freetype/config/ftconfig.h \
  /usr/include/freetype2/freetype/config/ftoption.h \
  /usr/include/freetype2/freetype/config/ftstdlib.h \
  /usr/include/freetype2/freetype/config/integer-types.h \
  /usr/include/freetype2/freetype/config/public-macros.h \
  /usr/include/freetype2/freetype/config/mac-support.h \
  /usr/include/freetype2/freetype/fttypes.h \
  /usr/include/freetype2/freetype/ftsystem.h \
  /usr/include/freetype2/freetype/ftimage.h \
  /usr/include/freetype2/freetype/fterrors.h \
  /usr/include/freetype2/freetype/ftmoderr.h \
  /usr/include/freetype2/freetype/fterrdef.h client/sv/ui/font.h \
  client/sv/session/session.h client/sv/result.h client/sv/ui/status.h \
  client/sv/app.h client/sv/session/alerts.h client/sv/input/input.h \
  client/sv/diagnostics/runtime.h client/sv/ui/ui.h \
  client/sv/ui/message-text.h ../tests/sv/scenarios/hp-scenario.h \
  ../tests/sv/scenarios/message-scenario.h \
  ../tests/sv/scenarios/request-scenario.h \
  ../tests/sv/scenarios/lifecycle-scenario.h \
  client/sv/input/native-input.h \
  ../tests/sv/scenarios/geometry-scenario.h \
  ../tests/sv/scenarios/timing-scenario.h \
  ../tests/sv/scenarios/arch-scenario.h \
  ../tests/sv/scenarios/native-frame.h temporary/sv/synthetic.h
/usr/include/freetype2/ft2build.h:
/usr/include/freetype2/freetype/config/ftheader.h:
/usr/include/freetype2/freetype/freetype.h:
/usr/include/freetype2/freetype/config/ftconfig.h:
/usr/include/freetype2/freetype/config/ftoption.h:
/usr/include/freetype2/freetype/config/ftstdlib.h:
/usr/include/freetype2/freetype/config/integer-types.h:
/usr/include/freetype2/freetype/config/public-macros.h:
/usr/include/freetype2/freetype/config/mac-support.h:
/usr/include/freetype2/freetype/fttypes.h:
/usr/include/freetype2/freetype/ftsystem.h:
/usr/include/freetype2/freetype/ftimage.h:
/usr/include/freetype2/freetype/fterrors.h:
/usr/include/freetype2/freetype/ftmoderr.h:
/usr/include/freetype2/freetype/fterrdef.h:
client/sv/ui/font.h:
client/sv/session/session.h:
client/sv/result.h:
client/sv/ui/status.h:
client/sv/app.h:
client/sv/session/alerts.h:
client/sv/input/input.h:
client/sv/diagnostics/runtime.h:
client/sv/ui/ui.h:
client/sv/ui/message-text.h:
../tests/sv/scenarios/hp-scenario.h:
../tests/sv/scenarios/message-scenario.h:
../tests/sv/scenarios/request-scenario.h:
../tests/sv/scenarios/lifecycle-scenario.h:
client/sv/input/native-input.h:
../tests/sv/scenarios/geometry-scenario.h:
../tests/sv/scenarios/timing-scenario.h:
../tests/sv/scenarios/arch-scenario.h:
../tests/sv/scenarios/native-frame.h:
temporary/sv/synthetic.h:
