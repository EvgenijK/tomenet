.sv-build/linux/9dd5a1e98a672a5b25cd/protocol.o: client/sv/protocol.c \
  client/sv/../../common/angband.h \
  client/sv/../../common/../common/h-basic.h \
  client/sv/../../common/../common/../h-config.h \
  client/sv/../../common/../common/h-system.h \
  client/sv/../../common/../common/h-type.h \
  client/sv/../../common/../common/h-define.h \
  client/sv/../../common/../common/h-net.h \
  client/sv/../../common/../common/sockbuf.h \
  client/sv/../../common/../common/net-unix.h \
  client/sv/../../common/../common/pack.h \
  client/sv/../../common/../common/bit.h \
  client/sv/../../common/../common/z-util.h \
  client/sv/../../common/../common/z-virt.h \
  client/sv/../../common/../common/z-form.h \
  client/sv/../../common/../common/z-rand.h \
  client/sv/../../common/z-term.h client/sv/../../common/h-basic.h \
  client/sv/../../common/../config.h \
  client/sv/../../common/../common/defines.h \
  client/sv/../../common/../common/defines-local.h \
  client/sv/../../common/../common/defines-features.h \
  client/sv/../../common/../common/defines-features-local.h \
  client/sv/../../common/../common/colours.h \
  client/sv/../../common/../server/quests-defines.h \
  client/sv/../../common/../common/types.h \
  client/sv/../../common/externs.h client/sv/../../common/sockbuf.h \
  client/sv/../../common/pack.h client/sv/hp-update.h \
  client/sv/message-update.h client/sv/key-request.h \
  client/sv/protocol.h client/sv/result.h client/sv/session.h
client/sv/../../common/angband.h:
client/sv/../../common/../common/h-basic.h:
client/sv/../../common/../common/../h-config.h:
client/sv/../../common/../common/h-system.h:
client/sv/../../common/../common/h-type.h:
client/sv/../../common/../common/h-define.h:
client/sv/../../common/../common/h-net.h:
client/sv/../../common/../common/sockbuf.h:
client/sv/../../common/../common/net-unix.h:
client/sv/../../common/../common/pack.h:
client/sv/../../common/../common/bit.h:
client/sv/../../common/../common/z-util.h:
client/sv/../../common/../common/z-virt.h:
client/sv/../../common/../common/z-form.h:
client/sv/../../common/../common/z-rand.h:
client/sv/../../common/z-term.h:
client/sv/../../common/h-basic.h:
client/sv/../../common/../config.h:
client/sv/../../common/../common/defines.h:
client/sv/../../common/../common/defines-local.h:
client/sv/../../common/../common/defines-features.h:
client/sv/../../common/../common/defines-features-local.h:
client/sv/../../common/../common/colours.h:
client/sv/../../common/../server/quests-defines.h:
client/sv/../../common/../common/types.h:
client/sv/../../common/externs.h:
client/sv/../../common/sockbuf.h:
client/sv/../../common/pack.h:
client/sv/hp-update.h:
client/sv/message-update.h:
client/sv/key-request.h:
client/sv/protocol.h:
client/sv/result.h:
client/sv/session.h:
