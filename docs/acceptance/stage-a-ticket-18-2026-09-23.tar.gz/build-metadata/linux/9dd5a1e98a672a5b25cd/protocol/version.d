.sv-build/linux/9dd5a1e98a672a5b25cd/protocol/version.o: \
  client/sv/protocol/version.c \
  client/sv/protocol/../../../common/angband.h \
  client/sv/protocol/../../../common/../common/h-basic.h \
  client/sv/protocol/../../../common/../common/../h-config.h \
  client/sv/protocol/../../../common/../common/h-system.h \
  client/sv/protocol/../../../common/../common/h-type.h \
  client/sv/protocol/../../../common/../common/h-define.h \
  client/sv/protocol/../../../common/../common/h-net.h \
  client/sv/protocol/../../../common/../common/sockbuf.h \
  client/sv/protocol/../../../common/../common/net-unix.h \
  client/sv/protocol/../../../common/../common/pack.h \
  client/sv/protocol/../../../common/../common/bit.h \
  client/sv/protocol/../../../common/../common/z-util.h \
  client/sv/protocol/../../../common/../common/z-virt.h \
  client/sv/protocol/../../../common/../common/z-form.h \
  client/sv/protocol/../../../common/../common/z-rand.h \
  client/sv/protocol/../../../common/z-term.h \
  client/sv/protocol/../../../common/h-basic.h \
  client/sv/protocol/../../../common/../config.h \
  client/sv/protocol/../../../common/../common/defines.h \
  client/sv/protocol/../../../common/../common/defines-local.h \
  client/sv/protocol/../../../common/../common/defines-features.h \
  client/sv/protocol/../../../common/../common/defines-features-local.h \
  client/sv/protocol/../../../common/../common/colours.h \
  client/sv/protocol/../../../common/../server/quests-defines.h \
  client/sv/protocol/../../../common/../common/types.h \
  client/sv/protocol/../../../common/externs.h
client/sv/protocol/../../../common/angband.h:
client/sv/protocol/../../../common/../common/h-basic.h:
client/sv/protocol/../../../common/../common/../h-config.h:
client/sv/protocol/../../../common/../common/h-system.h:
client/sv/protocol/../../../common/../common/h-type.h:
client/sv/protocol/../../../common/../common/h-define.h:
client/sv/protocol/../../../common/../common/h-net.h:
client/sv/protocol/../../../common/../common/sockbuf.h:
client/sv/protocol/../../../common/../common/net-unix.h:
client/sv/protocol/../../../common/../common/pack.h:
client/sv/protocol/../../../common/../common/bit.h:
client/sv/protocol/../../../common/../common/z-util.h:
client/sv/protocol/../../../common/../common/z-virt.h:
client/sv/protocol/../../../common/../common/z-form.h:
client/sv/protocol/../../../common/../common/z-rand.h:
client/sv/protocol/../../../common/z-term.h:
client/sv/protocol/../../../common/h-basic.h:
client/sv/protocol/../../../common/../config.h:
client/sv/protocol/../../../common/../common/defines.h:
client/sv/protocol/../../../common/../common/defines-local.h:
client/sv/protocol/../../../common/../common/defines-features.h:
client/sv/protocol/../../../common/../common/defines-features-local.h:
client/sv/protocol/../../../common/../common/colours.h:
client/sv/protocol/../../../common/../server/quests-defines.h:
client/sv/protocol/../../../common/../common/types.h:
client/sv/protocol/../../../common/externs.h:
